/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
@TemplateRegistration(folder = "Cache", content = "clsTemplate.cls", displayName = "Cache Class")
package org.nbstudio.core.cls;

import org.netbeans.api.templates.TemplateRegistration;
