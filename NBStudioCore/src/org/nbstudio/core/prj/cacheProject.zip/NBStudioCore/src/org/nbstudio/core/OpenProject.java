/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.nbstudio.core;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JFileChooser;
import org.nbstudio.cachefilechooser.CacheFileChooser;
import org.nbstudio.cachefilechooser.CacheFileNameExtensionFilter;
import org.netbeans.api.project.Project;
import org.netbeans.api.project.ProjectManager;
import org.netbeans.api.project.ui.OpenProjects;
import org.openide.awt.ActionID;
import org.openide.awt.ActionRegistration;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.URLMapper;

/**
 *
 * @author daimor
 */
@ActionID(category = "Project", id = "org.netbeans.modules.project.ui.OpenProject")
@ActionRegistration(
        displayName = "org.nbstudio.Bundle#CTL_OpenProject",
        iconBase = "org/nbstudio/core/resources/openProject.png")
public class OpenProject implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            CacheFileChooser fileChooser = new CacheFileChooser();
            fileChooser.setMultiSelectionEnabled(false);
            fileChooser.getFileSystemView().setShowProjectFiles(true);
            fileChooser.setAcceptAllFileFilterUsed(false);
            fileChooser.addChoosableFileFilter(new CacheFileNameExtensionFilter("Project files", new String[]{"prj"}));
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            int answer = fileChooser.showOpenDialog(null);
            if (answer == JFileChooser.APPROVE_OPTION) {
                File[] files;
                if (fileChooser.isMultiSelectionEnabled()) {
                    files = fileChooser.getSelectedFiles();
                } else {
                    files = new File[]{fileChooser.getSelectedFile()};
                }
                for (File file : files) {
                    FileObject fileObject = URLMapper.findFileObject(file.toURI().toURL());
                    Project prj = ProjectManager.getDefault().findProject(fileObject);
                    OpenProjects.getDefault().open(new Project[]{prj}, false);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
