/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
@TemplateRegistration(folder = "Cache", content = "macTemplate.mac", displayName = "MAC Routine")
package org.nbstudio.core.mac;

import org.netbeans.api.templates.TemplateRegistration;
