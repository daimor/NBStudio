/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
@TemplateRegistration(folder = "Cache", content = "basTemplate.bas", displayName = "BAS Routine")
package org.nbstudio.core.bas;

import org.netbeans.api.templates.TemplateRegistration;
