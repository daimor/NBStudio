/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.nbstudio.core.mac;

import java.util.EventListener;

/**
 *
 * @author daimor
 */
public interface macEventListener extends EventListener {
    
}
