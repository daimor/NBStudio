/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.nbstudio.core;

import java.beans.PropertyChangeListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import org.nbstudio.cachefilesystem.CacheFileObject;
import org.netbeans.api.project.Project;
import org.netbeans.api.project.ProjectInformation;
import org.netbeans.spi.project.ProjectState;
import org.openide.filesystems.FileObject;
import org.openide.util.ImageUtilities;
import org.openide.util.Lookup;
import org.openide.util.lookup.Lookups;

/**
 *
 * @author daimor
 */
public class CacheProject implements Project {

    private Lookup lkp;
    private final FileObject prj;
    private final ProjectState state;
    private final Connection conn;

    public CacheProject(FileObject prj, ProjectState state) {
        this.prj = prj;
        this.state = state;
        if (prj instanceof CacheFileObject) {
            String connName = ((CacheFileObject) prj).toURL().getHost();
            this.conn = Connection.getConnection(connName);
        } else {
            this.conn = null;
        }
    }

    @Override
    public FileObject getProjectDirectory() {
        return prj;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof CacheProject) {
            return this.prj.equals(((CacheProject) obj).getProjectDirectory());
        } else {
            return false;
        }
    }

    @Override
    public Lookup getLookup() {
        if (lkp == null) {
            lkp = Lookups.fixed(new Object[]{
                new Info(),
                new CacheProjectLogicalView(this)
            });
        }
        return lkp;
    }

    public final class Info implements ProjectInformation {

        @Override
        public String getName() {
            return conn.getTitle() + (prj.isRoot() ? "" : ": " + prj.getName());
        }

        @Override
        public String getDisplayName() {
            return getName();
        }

        @Override
        public Icon getIcon() {
            return new ImageIcon(ImageUtilities.loadImage("resources/prjFilesIcon.gif"));
        }

        @Override
        public Project getProject() {
            return CacheProject.this;
        }

        @Override
        public void addPropertyChangeListener(PropertyChangeListener listener) {
        }

        @Override
        public void removePropertyChangeListener(PropertyChangeListener listener) {
        }
    }
}
